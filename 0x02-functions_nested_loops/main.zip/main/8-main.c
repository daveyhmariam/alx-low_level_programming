#include"../main.h"

/**
 * main- check the code for ALX School students.
 *
 * Return: Always 0 (Success)
*/

int main(void)
{
	jack_bauer();
	return (0);
}
